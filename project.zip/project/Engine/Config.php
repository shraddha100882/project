<?php

namespace AuthorProject\Engine;

final class Config
{
    // Database info
    const
    DB_HOST = 'localhost',
    DB_NAME = 'Author',
    DB_USR = 'root',
    DB_PWD = 'shopclues',

    // Site title
    SITE_NAME = 'My Stories';
}
