<?php

namespace AuthorProject\Model;

class Admin extends Blog
{
    public function login($sEmail,$sPassword)
    {
        
        $oStmt = $this->oDb->prepare('SELECT firstname,lastname,email, password FROM Author_detail WHERE email = :email AND  password=:pwd LIMIT 1');
        $oStmt->bindValue(':email', $sEmail, \PDO::PARAM_STR);
        $oStmt->bindValue(':pwd',$sPassword);
        $oStmt->execute();
        $oRow = $oStmt->fetch(\PDO::FETCH_OBJ);

        return 1;
    }
}
