<?php if(!empty($_SESSION['is_logged'])): ?>

    <button type="button" onclick="window.location='<?=ROOT_URL?>?p=story&amp;a=edit&amp;id=<?=$oPost->story_id?>'" class="bold">Edit</button> |
    <form action="<?=ROOT_URL?>?p=story&amp;a=delete&amp;id=<?=$oPost->story_id?>" method="post" class="inline"><button type="submit" name="delete" value="1" class="bold">Delete</button></form> |
    <button type="button" onclick="window.location='<?=ROOT_URL?>?p=story&amp;author_id=<?=$oPost->author_id?>&amp;a=add'" class="bold">Add New Story</button>

<?php endif ?>
