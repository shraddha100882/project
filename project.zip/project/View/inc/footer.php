
            <footer>
                <p class="italic"><strong><a href="<?=ROOT_URL?>" title="Homeage">View Stories</a></strong>
                <?php if (!empty($_SESSION['is_logged'])): ?>
                    Admin - <a href="<?=ROOT_URL?>?p=admin&amp;a=logout">Logout</a> &nbsp; | &nbsp;
                    <a href="<?=ROOT_URL?>?p=story&amp;a=all">View All Stories Posts</a>
                <?php else: ?>
                    <a href="<?=ROOT_URL?>?p=admin&amp;a=login">Login</a>
                <?php endif ?>
                </p>
            </footer>
        </div>
    </body>
</html>
