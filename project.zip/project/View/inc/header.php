
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?=\AuthorProject\Engine\Config::SITE_NAME?></title>
        <meta name="author" content="Pierre-Henry Soria" />
        <link rel="stylesheet" href="<?=ROOT_URL?>static/style.css" />
    </head>
    <body>
        <div class="center">
