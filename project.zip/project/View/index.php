<?php echo "test" ?>

<?php if (empty($this->oPosts)): ?>
    <p class="bold">There is no Story.</p>
    <p><button type="button" onclick="window.location='<?=ROOT_URL?>?p=blog&amp;a=add'" class="bold">Add Your Story!</button></p>
<?php else: ?>

    <?php foreach ($this->oPosts as $oPost): ?>
        <h1><a href="<?=ROOT_URL?>?p=story&amp;a=post&amp;id=<?=$oPost->story_id?>"><?=htmlspecialchars($oPost->title)?></a></h1>

        <p><?=nl2br($oPost->story)?></p>
        <p class="left small italic">Posted on <?=$oPost->creation_date?></p>

        <?php require 'inc/control_buttons.php' ?>
        <hr class="clear" /><br />
    <?php endforeach ?>

<?php endif ?>

<?php require 'inc/footer.php' ?>
