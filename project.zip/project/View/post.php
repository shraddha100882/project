<?php require 'inc/header.php' ?>

<?php if (empty($this->oPost)): ?>
    <p class="error">The post can't be be found!</p>
<?php else: ?>

    <article>
        <time datetime="<?=$this->oPost->creation_date?>" pubdate="pubdate"></time>

        <h1>Title-><?=htmlspecialchars($this->oPost->title)?></h1>
        <p>Story-><?=nl2br(htmlspecialchars($this->oPost->story))?></p>
        <p class="left small italic">Posted on <?=$this->oPost->creation_date?></p>

        <?php
            $oPost = $this->oPost;
            require 'inc/control_buttons.php';
        ?>
    </article>

<?php endif ?>

<?php require 'inc/footer.php' ?>
